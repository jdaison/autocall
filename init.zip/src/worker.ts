/**
 * Worker: detecta nuevas filas en call_sessions (status = 'created')
 * y dispara twilio.calls.create.
 */
import {
  insertLogTranscripcion,
  listLlamadasPendientes,
  updateLlamadaCallingSid,
  updateLlamadaEstado,
} from './db';
import { config } from './config';
import twilio from 'twilio';

const POLL_INTERVAL_MS = 3000;

function getTwilioClient(): ReturnType<typeof twilio> {
  const { accountSid, authToken } = config.twilio;
  if (!accountSid || !authToken) {
    throw new Error('TWILIO_ACCOUNT_SID y TWILIO_AUTH_TOKEN son obligatorios.');
  }
  return twilio(accountSid, authToken);
}

async function procesarPendientes(): Promise<void> {
  const rows = await listLlamadasPendientes(5);
  if (rows.length === 0) return;

  const client = getTwilioClient();
  const baseUrl = config.webhookBaseUrl;

  for (const llamada of rows) {
    try {
      const answerUrl = `${baseUrl}/twilio/answer?llamada_id=${encodeURIComponent(llamada.id)}`;
      const statusCallback = `${baseUrl}/twilio/status?call_session_id=${encodeURIComponent(llamada.id)}`;

      const call = await client.calls.create({
        to: llamada.numero_destino,
        from: config.twilio.voiceNumber,
        url: answerUrl,
        statusCallback,
        statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
        timeout: 60,
        machineDetection: 'DetectMessageEnd',
        machineDetectionTimeout: 30,
      });

      await updateLlamadaCallingSid(llamada.id, call.sid);
      await log(llamada.id, `Twilio call created: ${call.sid}. Estado: calling.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      await updateLlamadaEstado(llamada.id, 'failed');
      await log(llamada.id, `Error Twilio: ${msg}. Estado: failed.`);
    }
  }
}

async function log(llamadaId: string, texto: string): Promise<void> {
  await insertLogTranscripcion(llamadaId, texto, 'evento');
}

export function startCallWorker(): void {
  console.log('Worker started. Polling call_sessions (status = created) every', POLL_INTERVAL_MS, 'ms.');
  const run = async (): Promise<void> => {
    for (;;) {
      try {
        await procesarPendientes();
      } catch (e) {
        console.error('Worker error:', e);
      }
      await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
    }
  };
  run();
}
