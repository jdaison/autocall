import express, { Request, Response } from 'express';
import { twimlAnswer, twimlGather, twimlSayDato } from './twiml';
import { resolverDatoUsuario } from './voice';
import {
  getLlamadaById,
  getLlamadaConIdentificacion,
  getLlamadaIdByTwilioSid,
  getLlamadaObjetivoById,
  getNombreUsuarioByLlamada,
  insertLogTranscripcion,
  updateLlamadaEstado,
} from './db';
import { config } from './config';

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'callcenter-anti-bureaucracy' });
});

app.get('/twilio/answer', async (req: Request, res: Response) => {
  const llamadaId = req.query.llamada_id as string;
  if (!llamadaId) {
    res.status(400).type('text/xml').send('<?xml version="1.0"?><Response><Say>Error: falta llamada_id</Say></Response>');
    return;
  }

  const llamada = await getLlamadaById(llamadaId);
  if (!llamada) {
    res.status(404).type('text/xml').send('<?xml version="1.0"?><Response><Say>Llamada no encontrada.</Say></Response>');
    return;
  }

  const nombre = await getNombreUsuarioByLlamada(llamadaId);
  const objetivo = (await getLlamadaObjetivoById(llamadaId)) ?? 'consultar';

  await updateLlamadaEstado(llamadaId, 'calling');
  await logTranscripcion(llamadaId, 'Llamada contestada; reproduciendo presentación.', 'evento');

  const xml = twimlAnswer(nombre, objetivo, llamadaId);
  res.type('text/xml').send(xml);
});

app.post('/twilio/answer', (req: Request, res: Response) => {
  const llamadaId = (req.body?.llamada_id ?? req.query?.llamada_id) as string;
  if (llamadaId) {
    res.redirect(302, `/twilio/answer?llamada_id=${encodeURIComponent(llamadaId)}`);
  } else {
    res.status(400).type('text/xml').send('<?xml version="1.0"?><Response><Say>Error: falta llamada_id</Say></Response>');
  }
});

app.get('/twilio/gather', async (req: Request, res: Response) => {
  const llamadaId = req.query.llamada_id as string;
  if (!llamadaId) {
    res.status(400).type('text/xml').send('<?xml version="1.0"?><Response><Say>Error: falta llamada_id</Say></Response>');
    return;
  }

  await updateLlamadaEstado(llamadaId, 'in_queue');
  const xml = twimlGather(llamadaId);
  res.type('text/xml').send(xml);
});

app.post('/twilio/gather', (req: Request, res: Response) => {
  const llamadaId = req.body?.llamada_id ?? req.query?.llamada_id;
  if (llamadaId) {
    res.redirect(302, `/twilio/gather?llamada_id=${encodeURIComponent(llamadaId)}`);
  } else {
    res.status(400).type('text/xml').send('<?xml version="1.0"?><Response><Say>Error.</Say></Response>');
  }
});

app.post('/twilio/gather-result', async (req: Request, res: Response) => {
  const llamadaId = (req.body?.llamada_id ?? req.query?.llamada_id) as string;
  const digits = req.body?.Digits;

  if (!llamadaId) {
    res.status(400).type('text/xml').send('<?xml version="1.0"?><Response><Say>Error.</Say></Response>');
    return;
  }

  const llamada = await getLlamadaConIdentificacion(llamadaId);

  if (llamada && digits !== undefined) {
    await logTranscripcion(llamadaId, `DTMF recibido: ${digits}`, 'evento');
    const pregunta = (req.body?.SpeechResult ?? req.body?.pregunta ?? '') as string;
    if (pregunta && llamada.identificacion_json) {
      const dato = resolverDatoUsuario(llamada.identificacion_json, pregunta);
      if (dato) {
        const xml = twimlSayDato(dato, llamadaId);
        res.type('text/xml').send(xml);
        return;
      }
    }
  }

  const xml = twimlGather(llamadaId);
  res.type('text/xml').send(xml);
});

app.post('/twilio/status', async (req: Request, res: Response) => {
  const CallSid = req.body?.CallSid;
  const CallStatus = req.body?.CallStatus;
  const From = req.body?.From;
  const sessionIdFromQuery = (req.query?.call_session_id ?? req.body?.call_session_id) as string | undefined;

  res.type('text/xml').send('<?xml version="1.0"?><Response></Response>');

  if (!CallStatus) return;

  const estadoMap: Record<string, import('./types').EstadoLlamada> = {
    completed: 'completed',
    busy: 'failed',
    failed: 'failed',
    'no-answer': 'no_answer',
    canceled: 'failed',
  };
  const nuevoEstado = estadoMap[CallStatus] ?? 'completed';

  const llamadaId = sessionIdFromQuery ?? (CallSid ? await getLlamadaIdByTwilioSid(CallSid) : null);
  if (!llamadaId) return;

  await updateLlamadaEstado(llamadaId, nuevoEstado);
  await logTranscripcion(
    llamadaId,
    `StatusCallback: ${CallStatus} (From: ${From ?? 'N/A'}). Estado actualizado a ${nuevoEstado}.`,
    'evento'
  );
});

app.post('/twilio/human-detected', async (req: Request, res: Response) => {
  const llamadaId = req.body?.llamada_id ?? req.query?.llamada_id;
  const CallSid = req.body?.CallSid;
  const sessionIdFromQuery = (req.query?.call_session_id ?? req.body?.call_session_id) as string | undefined;

  res.status(200).json({ ok: true });

  const id = (llamadaId as string | undefined) ?? sessionIdFromQuery ?? (CallSid ? await getLlamadaIdByTwilioSid(CallSid) : null);
  if (!id) return;

  await updateLlamadaEstado(id, 'talking_to_human');
  await logTranscripcion(id, 'Humano detectado; estado actualizado a talking_to_human.', 'evento');
});

async function logTranscripcion(llamadaId: string, texto: string, tipo: string): Promise<void> {
  await insertLogTranscripcion(llamadaId, texto, tipo);
}

import { startCallWorker } from './worker';

app.listen(config.port, () => {
  console.log(`Server listening on port ${config.port}. Webhooks: ${config.webhookBaseUrl}`);
});

startCallWorker();
